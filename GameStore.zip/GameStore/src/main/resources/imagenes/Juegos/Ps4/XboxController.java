package controller;

public class XboxController {
}
