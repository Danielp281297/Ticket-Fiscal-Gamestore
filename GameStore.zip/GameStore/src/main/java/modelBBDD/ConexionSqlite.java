package modelBBDD;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionSqlite {

    private static ConexionSqlite   conexionSqlite;

    //private String url= System.getProperty("user.dir")+"\\src\\main\\resources\\BBDD\\gameStore.db";;
    private String url= System.getProperty("user.dir")+"/src/main/resources/BBDD/gameStore.db";


    public static ConexionSqlite getInstance() {

        if (conexionSqlite == null) {
            conexionSqlite = new ConexionSqlite();
        }
        return conexionSqlite;
    }
    public Connection getConnection() throws SQLException {
        Connection connection= null;
        try{

            Class.forName("org.sqlite.JDBC");
            connection = DriverManager.getConnection( "jdbc:sqlite:" +url );
            if ( connection != null ){
                System.out.println("Conexión exitosa!");
            }
        } catch ( Exception ex ) {
            System.err.println( ex.getClass().getName() + ": " + ex.getMessage() );
            System.out.println("Error en la conexión");
        }
        return connection;
    }

    public void closeConnection(Connection connection){
        try {
            connection.close();

        } catch (SQLException ex) {
            System.out.println("Error en la conexión");
        }
    }

}
