module com.example.gamestore {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.gamestore to javafx.fxml;
    exports com.example.gamestore;
    exports controller;
    opens controller to javafx.fxml;
}