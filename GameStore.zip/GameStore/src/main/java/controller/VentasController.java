package controller;

public class VentasController {
}
