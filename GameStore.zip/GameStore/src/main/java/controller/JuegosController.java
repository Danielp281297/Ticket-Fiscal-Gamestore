package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.util.ArrayList;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class JuegosController implements Initializable {

    @FXML
    private Button cambiops4,cambiops5,cambioxbox,cambiotodo;

    @FXML
    private Pane cambiopane;

    @FXML
    private Pane ps4View,ps5View,xboxView,todoView;



    private Pane loadForm(String url) throws IOException {
        Pane pane = FXMLLoader.load(getClass().getResource(url));
        return pane;
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        try {
            ps4View = loadForm("/com/example/gamestore/Ps4View.fxml");
            ps5View = loadForm("/com/example/gamestore/Ps5View.fxml");
            xboxView = loadForm("/com/example/gamestore/XboxView.fxml");
            todoView = loadForm("/com/example/gamestore/TodoView.fxml");
            cambiopane.getChildren().addAll(ps4View,ps5View,xboxView,todoView);

            ps4View.setVisible(false);
            ps5View.setVisible(false);
            xboxView.setVisible(false);
            todoView.setVisible(true);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void cambiopane(ActionEvent event){

        Object object = event.getSource();
        if (cambiops4.equals(object)){
            ps4View.setVisible(true);
            ps5View.setVisible(false);
            xboxView.setVisible(false);
            todoView.setVisible(false);
        } else if (cambiops5.equals(object)) {
            ps4View.setVisible(false);
            ps5View.setVisible(true);
            xboxView.setVisible(false);
            todoView.setVisible(false);
        }else if (cambioxbox.equals(object)) {
            ps4View.setVisible(false);
            ps5View.setVisible(false);
            xboxView.setVisible(true);
            todoView.setVisible(false);
        }else if (cambiotodo.equals(object)) {
            ps4View.setVisible(false);
            ps5View.setVisible(false);
            xboxView.setVisible(false);
            todoView.setVisible(true);
        }
    }
}
