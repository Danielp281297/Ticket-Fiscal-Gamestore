package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class AccesoriosController {
    Arreglos bolsa = new Arreglos();

    @FXML
    private Button btn37, btn38, btn39, btn40,btn41,btn42,btn43, btn44, btn45, btn46, btn47, btn48;

    public void agregar(ActionEvent event){
        Object object = event.getSource();
        if(btn37.equals(object)){
            bolsa.agregarbolsa(37);

        }else if(btn38.equals(object)){
            bolsa.agregarbolsa(38);


        }else if(btn39.equals(object)){
            bolsa.agregarbolsa(39);


        }else if(btn40.equals(object)){
            bolsa.agregarbolsa(40);

        }else if(btn41.equals(object)){
            bolsa.agregarbolsa(41);

        }else if(btn42.equals(object)){
            bolsa.agregarbolsa(42);

        }else if(btn43.equals(object)){
            bolsa.agregarbolsa(43);

        }else if(btn44.equals(object)){
            bolsa.agregarbolsa(44);

        }else if(btn45.equals(object)){
            bolsa.agregarbolsa(45);

        }else if(btn46.equals(object)){
            bolsa.agregarbolsa(46);

        }else if(btn47.equals(object)){
            bolsa.agregarbolsa(47);

        }else if(btn48.equals(object)){
            bolsa.agregarbolsa(48);

        }
    }
}
