package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;
import modelBBDD.ConexionSqlite;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class AlmacenController  {

    @FXML
    private TableView<Producto> almacenTable;
    @FXML
    private TableColumn<Producto, String> columnaNombre,columnaPlataforma;
    @FXML
    private TableColumn<Producto, Number> columnaID,columnaCantidad;
    @FXML
    private TableColumn<Producto, Number> columnaPrecio;



    @FXML
    public void initialize() {
        ResultSet result = null;
        Connection connection = null;
        columnaNombre.setCellValueFactory(cellData -> cellData.getValue().getNombre());
        columnaPlataforma.setCellValueFactory(cellData -> cellData.getValue().getPlataforma());
        columnaID.setCellValueFactory(cellData -> cellData.getValue().getId());
        columnaCantidad.setCellValueFactory(cellData -> cellData.getValue().getCantidad());
        columnaPrecio.setCellValueFactory(cellData -> cellData.getValue().getPrecio());

        try {
            //Obtenemos la conexion a la base de datos
            connection = ConexionSqlite.getInstance().getConnection();

            if (connection != null) {
                //Se le indica al programa la sentencia a ejecutar
                PreparedStatement prepareStatement = connection.prepareStatement("select * from Producto");

                //Ejecutar Query es realizar la sentencia y se guarda en resul que es del tipo resulset linea 28...
                result = prepareStatement.executeQuery();

                //Creamos un ArrayList
                ObservableList<Producto> productoList = FXCollections.observableArrayList();;

                //Utilizamos un While para recorre la base de datos mientras hayan datos
                while (result.next()) {
                    productoList.add(new Producto(result.getInt("id"),
                            result.getString("Nombre"), result.getString("Plataforma"),
                            result.getInt("Cantidad"), result.getDouble("Precio")));
                }


                result.close();
                almacenTable.setItems(productoList);

                //state= result.next();

            } else {
                //lanzar mensaje
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {

            ConexionSqlite.getInstance().closeConnection(connection);
        }

    }

 public void actionReturn(ActionEvent event) throws IOException {

     ((Node) (event.getSource())).getScene().getWindow().hide();
     Parent root = FXMLLoader.load(getClass().getResource("/com/example/gamestore/GameStoreView.fxml"));
     Scene scene = new Scene(root);
     Stage newStage = new Stage();
     newStage.setResizable(false);
     newStage.setScene(scene);
     newStage.show();

 }




}
