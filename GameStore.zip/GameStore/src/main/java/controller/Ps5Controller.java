package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class Ps5Controller {

    Arreglos bolsa = new Arreglos();


    @FXML
    private Button btn13,btn14,btn15,btn16,btn17,btn18,btn19,btn20,btn21,btn22,btn23,btn24;
    public void agregar(ActionEvent event){
        Object object = event.getSource();
        if(btn13.equals(object)){
            bolsa.agregarbolsa(13);

        }else if(btn14.equals(object)){
            bolsa.agregarbolsa(14);


        }else if(btn15.equals(object)){
            bolsa.agregarbolsa(15);


        }else if(btn16.equals(object)){
            bolsa.agregarbolsa(16);

        }else if(btn17.equals(object)){
            bolsa.agregarbolsa(17);

        }else if(btn18.equals(object)){
            bolsa.agregarbolsa(18);

        }else if(btn19.equals(object)){
            bolsa.agregarbolsa(19);

        }else if(btn20.equals(object)){
            bolsa.agregarbolsa(20);

        }else if(btn21.equals(object)){
            bolsa.agregarbolsa(21);

        }else if(btn22.equals(object)){
            bolsa.agregarbolsa(22);

        }else if(btn23.equals(object)){
            bolsa.agregarbolsa(23);

        }else if(btn24.equals(object)){
            bolsa.agregarbolsa(24);

        }
    }
}
