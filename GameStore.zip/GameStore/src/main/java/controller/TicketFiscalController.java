package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

import java.io.IOException;

public class TicketFiscalController
{

    FacturaController ticketFiscal = new FacturaController();
    static Divisa tasa = new Divisa();


    final static int QUITAR_PAGO = 0;
    final static int EFECTIVO    = 1;
    final static int TDD         = 2;
    final static int TDC         = 3;
    final static int PAGO_MOVIL  = 4;
    final static int DOLAR       = 5;
    final static int EURO        = 6;
    final static int ZELLE       = 7;

    public int metodoAux = -1;

    // Aparece de nuevo la ventana principal
    PuntoVentaController volver = new PuntoVentaController();

    @FXML
    private CarritoController controladorGameStore;
    @FXML
    private Stage stage;
    @FXML
    private BorderPane TicketFiscalFrame;
    @FXML
    private Label RespuestaLabel;
    @FXML
    private Label LetreroMetodo;
    @FXML
    private Label TasaDolar;
    @FXML
    private Label TasaEuro;

    @FXML
    private TextArea MetodosDeclarados;
    @FXML
    private TextArea DatosCliente;

    @FXML
    private Label TipoMoneda;
    @FXML
    private Label LetreroPagoVuelto;

    @FXML
    private TextField EntradaMonto;

    @FXML
    private Button BotonCerrar;
    @FXML
    private Button MetodoEfectivo;
    @FXML
    private Button MetodoTDD;
    @FXML
    private Button MetodoTDC;
    @FXML
    private Button MetodoPagoMovil;
    @FXML
    private Button MetodoDOLAR;
    @FXML
    private Button MetodoEURO;
    @FXML
    private Button MetodoZELLE;
    @FXML
    private Button QuitarFormaPago;
    @FXML
    private Button DatosPersonales;
    @FXML
    private Button BotonImprimirFactura;
    @FXML
    private Button Invisible;

    @FXML
    private Label DatosCompra;
    @FXML
    private Label LetreroDatosPersonales;

    public static DatosPersonales datosPersonales = new DatosPersonales();
    // Metodo que, al presionar el boton "imprimir factura", muestra la factura emitida
    @FXML
    void ImprimirFacturaOnAction(ActionEvent event) throws IOException{

        //Si se ingresan los datos del cliente en la factura, se muestra la misma en pantalla
        if(datosPersonales.DatosBool == true) {

            // Se restablecen los datos predeterminados
            datosPersonales.DatosBool = false;

            //Se cierra la ventana del ticket fiscal

            ((Node) (event.getSource())).getScene().getWindow().hide();
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/gamestore/FacturaView.fxml"));
            Scene scene = new Scene(root);
            Stage newStage = new Stage();
            newStage.setScene(scene);
            newStage.setResizable(false);
            newStage.show();

        }
        else
            //Caso contrario, aparece el aviso en pantalla
            RespuestaLabel.setText("Por favor, ingrese los \n datos del cliente.");

    }

    //Metodo que, al presionar el boton invisible, despliega la vetana d los datos personales
    @FXML
    public void DatosPersonalesOnAction() throws IOException
    {
        /*
        Parent root = FXMLLoader.load(getClass().getResource("/com/example/gamestore/DatosPersonales-view.fxml"));
        Scene scene = new Scene(root);
        Stage newStage = new Stage();
        newStage.initStyle(StageStyle.UNDECORATED);
        newStage.setResizable(false);
        newStage.setScene(scene);
        newStage.show();
        */

        Stage stage = new Stage();
        FXMLLoader loader = new FXMLLoader();
        AnchorPane root = (AnchorPane)loader.load(getClass().getResource("/com/example/gamestore/DatosPersonales-view.fxml").openStream());
        //DatosPersonalesController datosPersonalesInstancia = (DatosPersonalesController)loader.getController();

        Scene scene = new Scene(root, 300, 400);
        stage.initStyle(StageStyle.UNDECORATED);

        stage.setScene(scene);
        stage.showAndWait();

        DatosCliente.setText(datosPersonales.ImprimirDatos());

    }

    // Metodo que imprime los datos del monto a pagar en la ventana
    public void DatosCompraOnAction()
    {
        DatosCompra.setText(ticketFiscal.DatosCompra(true));
    }

    public void LetreroPagoVueltoOnAction()
    {

        // Si ya esta todo pagado, entonces se desactivan los botones de los metodos y se habilita el boton de imprimir factura
        if((ticketFiscal.auxPago < 0.01) && (ticketFiscal.auxPago > -0.01))
        {

            // Se todos los botones de metodo
            QuitarFormaPago.setDisable(true);
            MetodoEfectivo.setDisable(true);
            MetodoTDD.setDisable(true);
            MetodoTDC.setDisable(true);
            MetodoPagoMovil.setDisable(true);
            MetodoDOLAR.setDisable(true);
            MetodoEURO.setDisable(true);
            MetodoZELLE.setDisable(true);
            BotonImprimirFactura.setDisable(false);

        }else
        if(ticketFiscal.auxPago < -0.001)
        {

            MetodoTDD.setDisable(true);
            MetodoTDC.setDisable(true);

            LetreroPagoVuelto.setText("VUELTO");

        }
        else LetreroPagoVuelto.setText("PAGO");

    }

    public void ImprimirMetodosDeclaradosOnAction()
    {

        MetodosDeclarados.setText("");

        //Si no hay pagos declarados, no se muestra la informacion del objeto ticketfiscal
        if(ticketFiscal.pos > 0)
            MetodosDeclarados.setText(ticketFiscal.ImprimirMetodosDeclarados());

    }

    public void HabilitarBotones()
    {
        // Si es un pago, se habilitan todos los botones de metodos
        System.out.println(ticketFiscal.auxPago);
        if(ticketFiscal.auxPago > 0.001)
        {

            MetodoEfectivo.setDisable(false);
            MetodoTDD.setDisable(false);
            MetodoTDC.setDisable(false);
            MetodoPagoMovil.setDisable(false);
            MetodoDOLAR.setDisable(false);
            MetodoEURO.setDisable(false);
            MetodoZELLE.setDisable(false);

        }
        else if(ticketFiscal.auxPago < -0.001)
        {
            MetodoEfectivo.setDisable(false);
            MetodoPagoMovil.setDisable(false);
            MetodoDOLAR.setDisable(false);
            MetodoEURO.setDisable(false);
            MetodoZELLE.setDisable(false);

        }

    }

    // Metodo que, captura cuando el usuario teclea uno de los botones, para poder determinar el tipo de metodo
    public void ActionPerformed(ActionEvent ae)
    {


        // Se presiona el boton de efectivo
        if(ae.getSource() == MetodoEfectivo)
        {

            metodoAux = EFECTIVO;
            LetreroMetodo.setText("EFECTIVO");

        }
        else
        // Se presiona el boton de tarjeta de debito
        if(ae.getSource() == MetodoTDD)
        {

            metodoAux = TDD;
            LetreroMetodo.setText("TARJETA DE DEBITO");

        }
        else
        // Se presiona el boton de tarjeta de credito
        if(ae.getSource() == MetodoTDC)
        {

            metodoAux = TDC;
            LetreroMetodo.setText("TARJETA DE CR" +(char)201 +"DITO");

        }
        else
        // Se presiona el boton de efectivo
        if(ae.getSource() == MetodoPagoMovil)
        {

            metodoAux = PAGO_MOVIL;
            LetreroMetodo.setText("PAGO M" +(char)211 +"VIL");

        }
        else
        // Se presiona el boton de efectivo
        if(ae.getSource() == MetodoDOLAR)
        {

            metodoAux = DOLAR;
            LetreroMetodo.setText("DIVISA D" +(char)211 +"LAR");

        }
        else
        // Se presiona el boton de efectivo
        if(ae.getSource() == MetodoEURO)
        {

            metodoAux = EURO;
            LetreroMetodo.setText("DIVISA EURO");

        }
        else
        // Se presiona el boton de efectivo
        if(ae.getSource() == MetodoZELLE)
        {

            metodoAux = ZELLE;
            LetreroMetodo.setText("ZELLE");

        }
        else
        // Se presiona el boton de efectivo
        if(ae.getSource() == QuitarFormaPago)
        {

            ticketFiscal.QuitarFormaPago();
            ImprimirMetodosDeclaradosOnAction();

            //Se actualizan los datos de los datos de compra
            DatosCompraOnAction();

            TipoMoneda.setText("");
            LetreroMetodo.setText(" ");
            metodoAux = -1;
            ImprimirMetodosDeclaradosOnAction();
            // Se habilitan los botones, dependiendo del ultimo metodo declarado
            HabilitarBotones();

        }

        //Se muestran el tipo de monto que hay que ingresar, dependiendo del boton pulsado
        if(ae.getSource() == MetodoEURO)//Euro
        {

            TipoMoneda.setText(" e");

        } else
        if(ae.getSource() == MetodoDOLAR || ae.getSource() == MetodoZELLE)   //Dolar
        {
            TipoMoneda.setText(" DS");
        }
        else if(ae.getSource() != QuitarFormaPago)//Bolivares
            TipoMoneda.setText(" BsD");

    }

    //Metodo que captura el monto que ingresa el usuario, y con el metodo, se procesa el pago
    public void Entrada()
    {

        boolean bandera = false;
        double monto = 0.00;

        // Se captura la cadena de la entrada de texto MOnto
        String cadena = EntradaMonto.getText();

        // Si se ingresa una cadena de caracteres vacia, se ignora
        if(!cadena.isBlank()) {
            //Se verifica si la cadena es numerica
            monto = ticketFiscal.EntradaTextoInvalido(cadena);

            // Si el monto es valido, se almacena en los atributos del objeto ticket fiscal
            if (monto > 0.01) {

                // Si el usuario persiono un boton del metodo de pago, se ejecuta la funcion
                if (metodoAux != -1) {

                    if(metodoAux == DOLAR || metodoAux == ZELLE) monto *= tasa.dolar;
                    else if(metodoAux == EURO) monto *= tasa.euro;

                    // Si se declara un vuelto, el valor del monto se pasa al opuesto
                    if(ticketFiscal.auxPago < -0.1) monto *= (-1);

                    // Se procesa el pago
                    ticketFiscal.ProcesarPago(metodoAux, monto);

                    //Se almacena en los vectores
                    ticketFiscal.pagos[ticketFiscal.pos] = monto;
                    ticketFiscal.metodos[ticketFiscal.pos] = metodoAux;

                    // Se incrementa el valor de las posiciones de los vectores
                    ticketFiscal.pos++;

                    //Se restablecen los valores auxiliares
                    LetreroMetodo.setText("");
                    RespuestaLabel.setText("");
                    metodoAux = -1;

                    //Se imprime el metodo declarado
                    if(cadena != "")ImprimirMetodosDeclaradosOnAction();

                    //Se actualizan los datos de los datos de compra
                    //Si la variable aux es menor a -0.001, se desabilitan los botones TDD, TDC para dar vuelto
                    LetreroPagoVueltoOnAction();
                    DatosCompraOnAction();

                } else // Caso contrario, se avisa del error
                    RespuestaLabel.setText(" Por favor ingrese \n un m" +(char)233 +"todo de pago");

            } else // Caso contrario, se avisa del error
                RespuestaLabel.setText(" Valor no admitido. \n Intente de nuevo");

            // Se limpia la entrada de texto
            EntradaMonto.clear();

        }
    }

    // Metodo del boton Cerrar, que manda a Cerrar la ventana
    public void BotonCerrarOnAction(ActionEvent event) throws IOException
    {
        // Se destruye el objeto
        ticketFiscal = null;
        datosPersonales.LimpiarAtributos();
        ((Node) (event.getSource())).getScene().getWindow().hide();
        Parent root = FXMLLoader.load(getClass().getResource("/com/example/gamestore/GameStoreView.fxml"));
        Scene scene = new Scene(root);
        Stage newStage = new Stage();
        newStage.setResizable(false);
        newStage.setScene(scene);
        newStage.show();

        // Aparece de nuevo la ventana principal
       // VolverInicio(stage);
        controladorGameStore.vaciarCarro();
    }

    public void setStage(Stage Stage) { stage = Stage;}

    // Metodo inicializar, que es la que permite imprimir los valores en la ventana al momento de abrirla
    @FXML
    public void inicializar(String datoCompra, double dolar, double euro, double montoDolares, Stage Stage, CarritoController gSController) {

        // Esto permite ocultar la ventana anterior, mientras esta esta abierta
        this.controladorGameStore = gSController;
        this.stage = Stage;

        montoDolares = controladorGameStore.MontoDolar;

        System.out.println(montoDolares);

        // Se imprime los montos de las divisas del dia
       TasaDolar.setText(String.valueOf(dolar) +" BsD");
       TasaEuro.setText(String.valueOf(euro) +" BsD");

        //Se imprime el tipo de metodo(pago) cuando se habra la ventana
        if(montoDolares > 0.001)
            LetreroPagoVuelto.setText("PAGO");
        else if(montoDolares < -0.001)
            LetreroPagoVuelto.setText("VUELTO");

        // Se muestran los datos del monto a pagar
        DatosCompra.setText(datoCompra);

    }

    public static void VolverInicio(Stage stage) throws IOException{

        // Aparece de nuevo la ventana principal
        //GameStoreApplication gameStoreApplication = new GameStoreApplication();
        //gameStoreApplication.Principal(stage);

    }



}