package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginPrincipalController {

    @FXML
    private AnchorPane loginView, loginAdmi, registroView;
    @FXML
    private AnchorPane loginPrincipalView;

    @FXML
    private Button irStore, userRegistro;

    @FXML
    public void ventanacambio(ActionEvent event) throws IOException {
        Object object = (Node) event.getSource();

        if (irStore.equals(object)) {

            ((Node) (event.getSource())).getScene().getWindow().hide();
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/gamestore/GameStoreView.fxml"));
            Scene scene = new Scene(root);
            Stage newStage = new Stage();
            newStage.setScene(scene);
            newStage.show();
        } else if (userRegistro.equals(object)) {

            ((Node) (event.getSource())).getScene().getWindow().hide();
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/gamestore/RegistroView.fxml"));
            Scene scene = new Scene(root);
            Stage newStage = new Stage();
            newStage.setScene(scene);
            newStage.show();
        }
    }

    }