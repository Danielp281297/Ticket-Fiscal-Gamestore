package controller;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javafx.beans.property.*;
import javafx.stage.Stage;

import static controller.Arreglos.bolsa;

public class FacturaController {

    // Atributos
    DatosPersonales datosPersonales = new DatosPersonales();
    @FXML
    CarritoController controller = new CarritoController();
    @FXML
    private TableColumn<Producto, Number> unidades, precioDolares, precioBs;
    @FXML
    private TableColumn<Producto, String> descripcion;
    @FXML
    private Button btncontinuar;
    @FXML
    private TableView<Producto> itemFactura;
    ObservableList<Producto> productoSeleccionado;
    @FXML
    private CarritoController controladorGameStore;
    final int MAX = 50;
    public int pos = 0;
    public int metodos[] = new int[MAX];
    public double pagos[] = new double[MAX];

    public static int numeroFactura = 0;

    //Esta es la variable que almacena los dolares de la compra
    public double dolares = (double) CarritoController.MontoDolar;

    public double Subtotal = dolares * Divisa.dolar;          // Variable subtotal en valor de dolares
    public double IVA = Subtotal * 0.16;

    public double total = Subtotal + IVA;

    public double auxPago = total;

    public static double impCredit = 0.00;
    public double impCreditaux = 0.00;

    public double IGTFaux = 0.00;

    public static double IGTF = 0.00;

    //Nodos
    @FXML
    private Label Cliente;
    @FXML
    private Label Direccion;
    @FXML
    private Label Identidad;

    @FXML
    private Label Telefono;
    @FXML
    private Label DatosCliente;
    @FXML
    private Label NumeroFactura;
    @FXML
    private Label FechaFactura;
    @FXML
    private Label DatosCompra;


    //Metodo para imprimir los pagos declarados, en la factura
    public String ImprimirMetodosDeclaradosFactura() {

        String aux = "";

        // Se recorren las posiciones de los vectores, imprimiento los pagos y vueltos declarados
        // Los pagos son reflejados como numero positivos, y los vueltos como numeros negativos
        for (int i = 0; i < pos; i++) {

            switch (metodos[i]) {

                case 01: // EFECTIVO
                    aux += " EFECTIVO: \t" + String.valueOf((float) pagos[i]) + " BsD \n";
                    break;

                case 02: // TDD
                    aux += " TDD: \t" + String.valueOf((float) pagos[i]) + " BsD \n";
                    break;

                case 03: // TDC
                    aux += " TDC: \t" + String.valueOf((float) pagos[i]) + " BsD \n";
                    break;

                case 04: // PAGO MOVIL
                    aux += " PAGO M" + (char) 211 + "VIL: \t" + String.valueOf((float) pagos[i]) + " BsD \n";
                    break;

                case 05: // DIVISA DOLAR
                    aux += " D" + (char) 211 + "LAR: \t" + String.valueOf((float) pagos[i]) + " BsD \n";
                    break;

                case 06: // DIVISA EURO
                    aux += " EURO: \t" + String.valueOf((float) pagos[i]) + " BsD \n";
                    break;

                case 07: // ZELLE
                    aux += " ZELLE: \t" + String.valueOf((float) pagos[i]) + " BsD \n";
                    break;
            }
        }
        return aux;

    }

    //Metodo que devuelve la fecha de emision de la factura
    public static String FechaDia() {

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String fecha = sdf.format(new Date());

        return fecha;

    }

    //Metodo que imprime los valores en la factura
    //Cuando se tengan los datos del carrito, estos tambien se envian como parametros para esta funcion
    @FXML
    public void ImprimirDatosFacturaOnAction(String metodosDeclarados) {

        //Se incrementa el numero de facturas emitidas
        numeroFactura++;

        // Se imprimen los datos de los montos de la compra, si su equivalente en dolares ni euros
        DatosCompra.setText(DatosCompra(false));

        // Se imprime los datos del cliente en la factura
        Identidad.setText(DatosPersonales.cedula);
        Cliente.setText(DatosPersonales.nombre);
        Direccion.setText(DatosPersonales.direccion);
        Telefono.setText(DatosPersonales.telefono);

        // Se imprimen los datos de la emision de la factura
        NumeroFactura.setText(String.valueOf(numeroFactura));
        FechaFactura.setText(FechaDia());

        //Por ultimo, se limpian los datos de la compra
        limpiarDatosCompra();

    }

    private void limpiarDatosCompra() {

        Subtotal = IGTF = impCredit = 0.00;

    }

    CarritoController carritoController = new CarritoController();

    public String DatosCompra(boolean condicion) {


        String aux = "";

        aux += "Subtotal:         " + String.valueOf(Math.ceil((Subtotal) * 100) / 100) + " BsD" + "\n";
        aux += "IVA:              " + String.valueOf(Math.ceil((IVA) * 100) / 100) + " BsD" + "\n";

        if (impCredit > 0.00)
            aux += "Impuesto Cr" + (char) 233 + "dito: " + String.valueOf(Math.ceil((impCredit) * 100) / 100) + " BsD" + "\n";

        if (IGTF > 0.00)
            aux += "IGTF:             " + String.valueOf(Math.ceil((IGTF) * 100) / 100) + " BsD" + "\n";

        aux += "Total:            " + String.valueOf(Math.ceil((total) * 100) / 100) + " BsD" + "\n";

        // Para reutilizar esta funcion en varias partes, se incluye el boolean condicion
        if (condicion == true) {
            aux += "Monto a";
            if (auxPago > 0.001) aux += " pagar";
            else if (auxPago < -0.01) aux += " devolver";
            aux += ": " + String.valueOf(Math.ceil((auxPago) * 100) / 100) + " BsD" + "\n";

            // Se muestran los equivalentes del monto a pagar, en dolares y euros
            aux += "\tDS: " + String.valueOf(Math.ceil((auxPago / Divisa.dolar) * 100) / 100) + " Ds" + "\n";
            aux += "\teuro: " + String.valueOf(Math.ceil((auxPago / Divisa.euro) * 100) / 100) + " e" + "\n";
        }

        return aux;

    }

    //Metodo para imprimir los metodos declarados de pago o vuelto
    public String ImprimirMetodosDeclarados() {

        String aux = "M" + (char) 201 + "TODOS: \n";

        if (pos > 0) {

            aux += "PAGO: \n";

            for (int i = 0; i < pos; i++) {

                if (pagos[i] > 0.01) {
                    switch (metodos[i]) {

                        case 01: // EFECTIVO
                            aux += " EFECTIVO: " + String.valueOf((float) pagos[i]) + " BsD \n";
                            break;

                        case 02: // TDD
                            aux += " TDD: " + String.valueOf((float) pagos[i]) + " BsD \n";
                            break;

                        case 03: // TDC
                            aux += " TDC: " + String.valueOf((float) pagos[i]) + " BsD \n";
                            aux += "\t Imp.CR" + (char) 201 + "DITO(2%):" + String.valueOf(Math.ceil((pagos[i] * 0.02) * 100) / 100) + " BsD  \n";
                            break;

                        case 04: // PAGO MOVIL
                            aux += " PAGO M" + (char) 211 + "VIL: " + String.valueOf((float) pagos[i]) + " BsD \n";
                            break;

                        case 05: // DIVISA DOLAR

                            aux += " D" + (char) 211 + "LAR(" + String.valueOf(Math.ceil((pagos[i] / Divisa.dolar) * 100) / 100) + " DS): " + String.valueOf((float) pagos[i]) + " BsD \n";
                            aux += "\t IGTF(3%):" + String.valueOf(Math.ceil((pagos[i] * 0.03) * 100) / 100) + " BsD  \n";
                            break;

                        case 06: // DIVISA EURO

                            aux += " EURO(" + String.valueOf(Math.ceil((pagos[i] / Divisa.euro) * 100) / 100) + " e): " + String.valueOf((float) pagos[i]) + " BsD \n";
                            aux += "\t IGTF(3%):" + String.valueOf(Math.ceil((pagos[i] * 0.03) * 100) / 100) + " BsD  \n";
                            break;

                        case 07: // ZELLE

                            aux += " ZELLE(" + String.valueOf(Math.ceil((pagos[i] / Divisa.dolar) * 100) / 100) + " DS): " + String.valueOf((float) pagos[i]) + " BsD \n";
                            aux += "\t IGTF(3%):" + String.valueOf(Math.ceil((pagos[i] * 0.03) * 100) / 100) + " BsD  \n";
                            break;
                    }
                }
            }

            aux += "VUELTO \n";

            for (int i = 0; i < pos; i++) {

                if (pagos[i] < -0.01) {
                    switch (metodos[i]) {

                        case 01: // EFECTIVO
                            aux += " EFECTIVO: " + String.valueOf((float) pagos[i]) + " BsD \n";
                            break;
                        case 04: // PAGO MOVIL
                            aux += " PAGO M" + (char) 211 + "VIL: " + String.valueOf((float) pagos[i]) + " BsD \n";
                            break;
                        case 05: // DIVISA DOLAR
                            aux += " D" + (char) 211 + "LAR(" + String.valueOf(Math.ceil((pagos[i] / Divisa.dolar) * 100) / 100) + " DS): " + String.valueOf((float) pagos[i]) + " BsD \n";
                            break;

                        case 06: // DIVISA EURO
                            aux += " EURO(" + String.valueOf(Math.ceil((pagos[i] / Divisa.euro) * 100) / 100) + " e): " + String.valueOf((float) pagos[i]) + " BsD \n";
                            break;

                        case 07: // ZELLE
                            aux += " ZELLE(" + String.valueOf(Math.ceil((pagos[i] / Divisa.dolar) * 100) / 100) + " DS): " + String.valueOf((float) pagos[i]) + " BsD \n";
                            break;
                    }
                }
            }
        }

        return aux;

    }

    // Metodo para esconder forma de pa
    public void QuitarFormaPago() {

        // Si hay varios metodos declarados, se ejecuta la secuencia
        if (pos > 0) {

            // Primero, se decrementa el numero de metodos
            pos--;

            /* Se devuelven el monto al valor a pagar */
            // Dependiendo del metodo de pago, se sustrae el monto de los impuestos declarados durante el pago
            if (metodos[pos] == TicketFiscalController.DOLAR || metodos[pos] == TicketFiscalController.EURO || metodos[pos] == TicketFiscalController.ZELLE) {

                IGTFaux = (pagos[pos] * 0.03);

                auxPago -= IGTFaux;
                IGTF -= IGTFaux;

                //Se sustrae el impuesto del monto total
                total -= IGTFaux;

            } else if (metodos[pos] == TicketFiscalController.TDC) {
                impCreditaux = (pagos[pos] * 0.02);

                auxPago -= impCreditaux;
                impCredit -= impCreditaux;

                total -= impCreditaux;

            }

            // Se adiciona el monto a la variable auxiliar de pago
            auxPago += pagos[pos];

        }
    }


    //Metodo para guardar los pagos declarados en los atributos del objeto
    public void ProcesarPago(int metodo, double pago) {

        //Dependiendo de la variable monto, se guarda la los pagos en el arreglo
        switch (metodo) {

            case 1: // EFECTIVO
            case 2: // Tarjeta de debito
            case 4: // Pago Movil
                auxPago -= pago;
                break;

            case 3: //Tarjeta de credito
                auxPago -= pago;
                impCreditaux = (pago * 0.02);
                impCredit += impCreditaux;
                auxPago += impCreditaux;
                total += impCreditaux;
                break;

            case 5: //DOLAR
            case 6: //EURO
            case 7: //ZELLE
                auxPago -= pago;
                if (pago > 0.009) {
                    IGTFaux = pago * 0.03;
                    IGTF += IGTFaux;
                    auxPago += IGTFaux;
                    total += IGTFaux;

                }
                break;

        }

        IGTFaux = 0.00;

    }

    //Metodo para comprobar la entrada de cadena de caracteres
    public double EntradaTextoInvalido(String cadena) {

        double aux = 0.00;
        boolean bandera = false;
        int puntoContador = 0;

        // Primero, se cambian los caracteres de coma, por puntos
        cadena = cadena.replaceAll(",", ".");

        // Se recorre la cadena caracter por caracter, para saber si los caracteres son numeros
        for (int i = 0; i < cadena.length() && bandera == false; i++) {

            char car = cadena.charAt(i);

            // Si car es un punto, se acumula en la variable
            if (car == '.') {
                puntoContador++;
            } else // Ahora, si el caracter no es numerico, la bandera es true, y se termina el bucle
                if ((car < '0' || car > '9')) bandera = true;

        }
        // Se comprueba si existen un solo punto en la cadena
        if (bandera == false)
            // Si hay entre 0 y 1 punto en la cadena, entonces se convierte la cadena en decimal
            if (puntoContador != 0 && puntoContador != 1) bandera = true;

        // Si la bandera es true, entonces aux + -1
        if (bandera == true) aux = -1.00;
        else // CAso contrario, se almacena el valor real en la variable double
        {

            aux = Double.valueOf(cadena);
            aux = (Math.round(aux * 100.00)) / 100.00;

        }
        return aux;

    }

    public void continuar(ActionEvent event) throws IOException {

        ((Node) (event.getSource())).getScene().getWindow().hide();
        Parent root = FXMLLoader.load(getClass().getResource("/com/example/gamestore/GameStoreView.fxml"));
        Scene scene = new Scene(root);
        Stage newStage = new Stage();
        newStage.setResizable(false);
        newStage.setScene(scene);
        newStage.show();
        Arreglos.bolsaString="";
        bolsa.clear();
        Arreglos.cantidadBolsa.clear();
    }

    @FXML
    public void initialize() {
        productoSeleccionado = Arreglos.obtenerProductoSeleccionado();
        itemFactura.setItems(productoSeleccionado);
        descripcion.setCellValueFactory(cellData -> cellData.getValue().getNombre());
        unidades.setCellValueFactory(cellData -> cellData.getValue().getCantidad());
        //precioDolares.setCellValueFactory(cellData -> cellData.getValue().getPrecio());
        precioBs.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().getPrecio().doubleValue() * Divisa.dolar));
        ImprimirDatosFacturaOnAction(ImprimirMetodosDeclaradosFactura());
    }
}
