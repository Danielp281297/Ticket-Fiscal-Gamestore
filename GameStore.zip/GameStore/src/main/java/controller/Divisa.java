package controller;

// Objeto que almacena los datos de la divisa del dia
// En el dia de la presentacion, hay que actualizar estas variables
public class Divisa
{

    public static double dolar = 29.51;

    public static double euro = 32.56;

}
