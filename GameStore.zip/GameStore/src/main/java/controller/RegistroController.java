package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class RegistroController implements Initializable {
    String typeUser;
    @FXML
    private TextField textFieldname;
    @FXML
    private TextField textFieldemail;
    @FXML
    private TextField textFielduser;
    @FXML
    private TextField textFieldce;
    @FXML
    private PasswordField textFieldclave;
    @FXML
    private PasswordField textFieldconfirmClave;
    @FXML
    private Button register;
    @FXML
    private Button goGameStore, longOut;
    @FXML
    private ComboBox boxtypeUser;
    @FXML
    private Label confirmClaveLabel;
    @FXML
    private Label ingreseName;
    @FXML
    private Label ingreseID;
    @FXML
    private Label emailNovalido;
    @FXML
    private Label ingreseUser;
    @FXML
    private Label vacioPassword;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        boxtypeUser.getItems().add("Administrador");
        boxtypeUser.getItems().add("Comercial");

    }

    public void opciononAction(ActionEvent event) {

        String type = boxtypeUser.getValue().toString();
        if (type.equals("Administrador")) {
            typeUser = "1";
        } else {
            typeUser = "0";
        }
    }

    public void registerOnAction(ActionEvent event) throws IOException { // Action Evente del boton registrar

        int bandera = 0;

        if (textFieldname.getText().isEmpty()) {
            ingreseName.setText(" Campo Requerido");
            bandera++;
        } else {
            ingreseName.setText("");
        }

        if (textFieldce.getText().isEmpty()) {
            ingreseID.setText("  Campo Requerido");
            bandera++;
        } else {
            ingreseID.setText("");
        }
        if (textFieldemail.getText().isEmpty()) {
            emailNovalido.setText(" Campo Requerido");
            bandera++;
        } else if (!textFieldemail.getText().contains("@") || !textFieldemail.getText().contains(".")) {
            emailNovalido.setText(" Correo Inválido");
            bandera++;
        } else {
            emailNovalido.setText("");
        }
        if (textFielduser.getText().isEmpty()) {
            ingreseUser.setText("  Campo Requerido");
            bandera++;
        } else {
            ingreseUser.setText("");
        }
        if (textFieldclave.getText().isEmpty()) {
            vacioPassword.setText("Campo Requerido");
            bandera++;
        } else {
            vacioPassword.setText("");
        }
        if (textFieldclave.getText().equals(textFieldconfirmClave.getText())) {
            confirmClaveLabel.setText("");

        } else {
            confirmClaveLabel.setText("La contraseña no es igual");
            bandera++;
        }
        if (bandera == 0) {
            LoginController nuevo = new LoginController();

            String name = textFieldname.getText();
            String id = textFieldce.getText();
            String email = textFieldemail.getText();
            String user = textFielduser.getText();
            String Clave = textFieldclave.getText();


            nuevo.datosUsuarios(typeUser, user, Clave, name, id, email);

        }


    }
    @FXML
    private void ventanacambiotres(ActionEvent event) throws IOException {
        Object object = (Node) event.getSource();

        if (goGameStore.equals(object)) {

            ((Node) (event.getSource())).getScene().getWindow().hide();
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/gamestore/GameStoreView.fxml"));
            Scene scene = new Scene(root);
            Stage newStage = new Stage();
            newStage.setScene(scene);
            newStage.setResizable(false);
            newStage.show();
        } else if (longOut.equals(object)) {

            ((Node) (event.getSource())).getScene().getWindow().hide();
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/gamestore/LoginView.fxml"));
            Scene scene = new Scene(root);
            Stage newStage = new Stage();
            newStage.setScene(scene);
            newStage.setResizable(false);
            newStage.show();
        }
    }

}
