package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class LoginController implements Initializable {
    public static String[][] usuarios = new String[20][6];


    @FXML
    private Button outbutton;
    @FXML
    private Label wrongLogin;

    @FXML
    private TextField username;
    @FXML
    private PasswordField password;


    public void outButtonOnAction(ActionEvent event) {
        Stage stage = (Stage) outbutton.getScene().getWindow();
        stage.close();

    }

    public void userLogin(ActionEvent event) throws IOException {
        checkLogin(usuarios, event);
    }

    public void datosUsuarios(String tipo, String usuario, String contraseña, String nombre, String cedula, String correo) {
        boolean salida = false;
        int i = 0;
        int posicion = 0;  //Orden de los datos (tipo de usuario) (usuario)(contraseña)(nombre)(cedúla)(correo)
        do {
            if (usuarios[i][0] == null) {
                salida = true;
                posicion = i;
                break;
            }
            i++;
        } while (!salida);


        usuarios[posicion][0] = tipo;
        usuarios[posicion][1] = usuario;
        usuarios[posicion][2] = contraseña;
        usuarios[posicion][3] = nombre;
        usuarios[posicion][4] = cedula;
        usuarios[posicion][5] = correo;

        imprimirMatriz();
    }

    public static void imprimirMatriz() {

        for (String[] matriz : usuarios) {
            for (String datos : matriz) {
                if (datos != null)
                    System.out.print(datos + " | ");
            }
            System.out.println(" ");
        }
    }

    private void checkLogin(String usuarios[][], ActionEvent event) throws IOException {

        for (int i = 0; i < 20; i++) {

            if (username.getText().toString().equals(usuarios[i][1]) && password.getText().equals(usuarios[i][2])) {
                wrongLogin.setText("     ");

                Arreglos.userHeader = usuarios[i][1];
                if (usuarios[i][0].equals("1")) {
                    ((Node) (event.getSource())).getScene().getWindow().hide();
                    Parent root = FXMLLoader.load(getClass().getResource("/com/example/gamestore/LoginAdmiView.fxml"));
                    Scene scene = new Scene(root);
                    Stage newStage = new Stage();
                    newStage.setScene(scene);
                    newStage.setResizable(false);
                    newStage.show();
                } else if (usuarios[i][0].equals("0")) {
                    ((Node) (event.getSource())).getScene().getWindow().hide();
                    Parent root = FXMLLoader.load(getClass().getResource("/com/example/gamestore/GameStoreView.fxml"));

                    root.setUserData(usuarios[i][01]);

                    Scene scene = new Scene(root);
                    Stage newStage = new Stage();
                    newStage.setScene(scene);
                    newStage.setResizable(false);
                    newStage.show();
                } else {
                    System.out.println("Hola Ambar");
                }

            } else if (username.getText().isEmpty() && password.getText().isEmpty()) {
                wrongLogin.setText("Por favor. Ingresa tus datos");
            } else {
                wrongLogin.setText("Usuario y/o contraseña incorrecto");
            }

        }
    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {


        //usuario 1 administrador
        usuarios[0][0] = "1";
        usuarios[0][1] = "12";
        usuarios[0][2] = "12";
        usuarios[0][3] = "Ambar";
        usuarios[0][4] = "30284643";
        usuarios[0][5] = "gamestore@gmail.com";
        //usuario 2 común
        usuarios[1][0] = "0";
        usuarios[1][1] = "IUTV";
        usuarios[1][2] = "IUTV";
        usuarios[1][3] = "Elena";
        usuarios[1][4] = "30284643";
        usuarios[1][5] = "gamestore@gmail.com";
        //usuario 3 Admin
        usuarios[2][0] = "1";
        usuarios[2][1] = "Gomeroto";
        usuarios[2][2] = "123";
        usuarios[2][3] = "Francisco";
        usuarios[2][4] = "12345678";
        usuarios[2][5] = "CodigoConArte@gmail.com";
        //usuario 4 Admin
        usuarios[3][0] = "1";
        usuarios[3][1] = "ParteCodigos";
        usuarios[3][2] = "123";
        usuarios[3][3] = "ParteCodigos";
        usuarios[3][4] = "12345678";
        usuarios[3][5] = "Parte@codigos.com";
        imprimirMatriz();

    }


}





