package controller;

public class DatosPersonales
{

    TicketFiscalController comunicacionTicketFiscal;

    public static String cedula = "";
    public static String nombre = "";
    public static String direccion = "";
    public static String telefono = "";
    public static boolean DatosBool = false;


    public static String ImprimirDatos()
    {

        String aux = "DATOS DEL CLIENTE: \n" ;

        aux += " C.I/R.I.F: " +cedula +"\n";
        aux += " NOMBRE: " +nombre +"\n";
        aux += " DIRECCI" +(char)211 +"N: " +direccion +"\n";
        aux += " TELEFONO: " +telefono +"\n";

        return aux;

    }

    public static void LimpiarAtributos() { cedula = nombre = direccion = telefono = "";}

    //Metodo para Verificar la cadena nombre...
    // Se verifica si la cadena es estrictamente alfabetica
    public static boolean TelefonoInvalido(String cadena)
    {

        boolean bandera = false;
        int guiones = 0;
        int digitos = 0;

        //Se recorre la cadena caracter por caracter, hasta conseguir un caracter no alfabetico
        for(int i = 0; i < cadena.length() && bandera == false; i++)
        {

            char car = cadena.charAt(i);

            if  (car == '-')
            {

                guiones++;
                if(guiones > 1) bandera = true;
            }
                else
            // Si el caracter no es alfanumerico, se termina el bucle
            if(Character.isDigit(car)) digitos++;
                else
                    bandera = true;

        }

        if((bandera == false) && (digitos != 11)) bandera = true;

        return bandera;

    }

    //Metodo para Verificar la cadena nombre...
    // Se verifica si la cadena es estrictamente alfabetica
    public static boolean DireccionInvalida(String cadena)
    {

        boolean bandera = false;

        //Se recorre la cadena caracter por caracter, hasta conseguir un caracter no alfabetico
        for(int i = 0; i < cadena.length() && bandera == false; i++)
        {

            char car = cadena.charAt(i);

            // Si el caracter no es alfanumerico, se termina el bucle
            if(!(Character.isLetterOrDigit(car) || car == ' ')) bandera = true;

        }

        return bandera;

    }

    //Metodo para Verificar la cadena nombre...
    // Se verifica si la cadena es estrictamente alfabetica
    public static boolean NombreInvalido(String cadena)
    {

        boolean bandera = false;

        //Se recorre la cadena caracter por caracter, hasta conseguir un caracter no alfabetico
        for(int i = 0; i < cadena.length() && bandera == false; i++)
        {

            char car = cadena.charAt(i);

            // Si el caracter no es alfabetico, se termina el bucle
            if(!(Character.isAlphabetic(car) || car == ' ')) bandera = true;

        }

        return bandera;

    }

    public static boolean Nacionalidad(char c)
    {

        boolean bandera = false;

        bandera = (c != 'V' && c != 'E' && c != 'P' && c != 'J' && c != 'G');

        return bandera;

    }

    //Metodo para Verificar la cadena identidad...
    public static boolean IdentidadInvalida(String cadena)
    {

        boolean bandera = false;

        // Se verifica Si el primer caracter es el tipo de Identidad
        bandera = Nacionalidad(cadena.charAt(0));

        for(int i = 1; i < cadena.length() && bandera == false; i++)
        {

            char car = cadena.charAt(i);

            if(!Character.isDigit(car)) bandera = true;

        }

        return bandera;

    }

}
