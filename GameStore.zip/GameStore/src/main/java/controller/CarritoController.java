package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static controller.Arreglos.*;

public class CarritoController /*implements Initializable*/ {

    @FXML
    private TableView tableCar;
    @FXML
    private TextField montoBs, montoDolar;

    @FXML
    private TableColumn<Producto, String> carritoProducto;
    @FXML
    private TableColumn<Producto, Number> carritoCantidad, carritoPrecio;

    @FXML
    private Button btnCCompra, btnCancelar, btnRetirar;

    ObservableList<Producto> productoSeleccionado;

    private Producto productoEliminar;

  /*  @Override
    public void initialize(URL location, ResourceBundle resources) {
        carritoProducto.setCellValueFactory(cellData -> cellData.getValue().getNombre());
        carritoCantidad.setCellValueFactory(cellData -> cellData.getValue().getCantidad());
        carritoPrecio.setCellValueFactory(cellData -> cellData.getValue().getPrecio());
        tableCar.setItems(productoSeleccionado);

    }*/

    @FXML
    public void initialize() throws IOException {
      /*  FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/com/example/gamestore/CarritoView.fxml"));
        Parent root = fxmlLoader.load();
        tableCar = (TableView) root.lookup("#tableCar");*/

        carritoProducto.setCellValueFactory(cellData -> cellData.getValue().getNombre());
        carritoCantidad.setCellValueFactory(cellData -> cellData.getValue().getCantidad());
        carritoPrecio.setCellValueFactory(cellData -> cellData.getValue().getPrecio());
        //  tableCar.setItems(cargarCarro ( ));


    }

    public ObservableList<Producto> cargarCarro() {
        productoSeleccionado = Arreglos.obtenerProductoSeleccionado();
        tableCar.setItems(productoSeleccionado);
        calcularMonto(productoSeleccionado);
        return productoSeleccionado;
    }

    public ObservableList<Producto> vaciarCarro() {
        productoSeleccionado.clear();
        montoBs.setText("0.0");
        montoDolar.setText("0.0");
        Arreglos.bolsaString="";
        bolsa.clear();
        Arreglos.cantidadBolsa.clear();
        return productoSeleccionado;
    }

    static double MontoDolar = 0.00;

    private void calcularMonto(ObservableList<Producto> productoSeleccionado) {
        double monto = 0.00;
        for (Producto productos : productoSeleccionado) {
            monto += (productos.getCantidad().intValue() * productos.getPrecio().doubleValue());
        }

        MontoDolar = monto;

        montoDolar.setText(String.valueOf(monto));
        montoBs.setText(String.valueOf(monto * Divisa.dolar));
    }

    public void onActionCarrito(ActionEvent event) throws IOException {
        Object object = event.getSource();

        if (btnCCompra.equals(object)){


            if(Arreglos.actualizarProductosBBDD(productoSeleccionado)&& !productoSeleccionado.isEmpty()){
                System.out.println("Actualizado");

                ((Node) (event.getSource())).getScene().getWindow().hide();

                FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/gamestore/TicketFiscal-view.fxml"));
                Parent root = loader.load();

                Scene scene = new Scene(root);
                Stage newStage = new Stage();

                //Valores iniciales
                TicketFiscalController controladorTikcetFiscal = (TicketFiscalController) loader.getController();
                FacturaController datosCompra = new FacturaController();

                controladorTikcetFiscal.inicializar(datosCompra.DatosCompra(true), Divisa.dolar, Divisa.euro, MontoDolar, newStage, this);

                newStage.setResizable(false);
                newStage.setScene(scene);
                newStage.showAndWait();

            }else{
                System.out.println("No Actualizado");
            }

        }else if (btnCancelar.equals(object)){
            vaciarCarro();
        }

    }

    public void retirarProducto (ActionEvent event){
     for( Producto producto: productoSeleccionado){
         if (productoEliminar.getId().equals(producto.getId())){
             productoSeleccionado.remove(producto);
             calcularMonto(productoSeleccionado);
                cantidadBolsa.remove(producto.getId());
            for (Integer bolsas : bolsa){
            if (bolsas.equals(productoEliminar.getId().intValue())){
                bolsa.remove(bolsas);
                break;
            }
            }

             break;
         }
     }


    }

    public void clickMouse(MouseEvent event){
        Object object = event.getSource();
        productoEliminar=(Producto) tableCar.getSelectionModel().getSelectedItem();
    }


}
