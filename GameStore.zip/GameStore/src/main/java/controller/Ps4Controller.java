package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class Ps4Controller {
    //ArrayList<Integer> bolsa = new ArrayList<>();
    Arreglos bolsa = new Arreglos();

    @FXML
    private Button btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,btn10,btn11,btn12;

    public void agregar(ActionEvent event){
        Object object = event.getSource();
        if(btn1.equals(object)){
            bolsa.agregarbolsa(1);

        }else if(btn2.equals(object)){
            bolsa.agregarbolsa(2);

        }else if(btn3.equals(object)){
            bolsa.agregarbolsa(3);

        }else if(btn4.equals(object)){
            bolsa.agregarbolsa(4);


        }else if(btn5.equals(object)){
            bolsa.agregarbolsa(5);

        }else if(btn6.equals(object)){
            bolsa.agregarbolsa(6);

        }else if(btn7.equals(object)){
            bolsa.agregarbolsa(7);

        }else if(btn8.equals(object)){
            bolsa.agregarbolsa(8);

        }else if(btn9.equals(object)){
            bolsa.agregarbolsa(9);

        }else if(btn10.equals(object)){
            bolsa.agregarbolsa(10);

        }else if(btn11.equals(object)){
            bolsa.agregarbolsa(11);

        }else if(btn12.equals(object)){
            bolsa.agregarbolsa(12);

        }
    }
}
