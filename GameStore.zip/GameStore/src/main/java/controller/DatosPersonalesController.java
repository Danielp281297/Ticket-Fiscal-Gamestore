package controller;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class DatosPersonalesController
{

    TicketFiscalController comunicacionTicketFiscal;

    @FXML
    private Stage stage;
    @FXML
    private Button BotonVolver;
    @FXML
    private Button BotonAceptar;

    @FXML
    private TextField EntradaIdentidad;
    @FXML
    private TextField EntradaNombre;
    @FXML
    private TextField EntradaDireccion;
    @FXML
    private TextField EntradaTelefono;

    @FXML
    private Label Aviso;

    public void EntradaTelefonoOnAction()
    {

        String cadena = EntradaTelefono.getText();

        if(DatosPersonales.TelefonoInvalido(cadena) == true)
        {

            Aviso.setText("Telefono Inv" +(char)225 +"lido");
            BotonAceptar.setDisable(true);

        }
        else
        {
            DatosPersonales.telefono = cadena;
            BotonAceptar.setDisable(false);
        }

    }

    public void EntradaDireccionOnAction()
    {

        String cadena = EntradaDireccion.getText();
        if(DatosPersonales.DireccionInvalida(cadena) == true)
        {

            Aviso.setText("Nombre Inv" +(char)225 +"lido");
            EntradaTelefono.setDisable(true);
            BotonAceptar.setDisable(true);

        }
        else
        {
            DatosPersonales.direccion = cadena;
            EntradaTelefono.setDisable(false);
        }

    }

    public void EntradaNombreOnAction()
    {

        String cadena = EntradaNombre.getText();
        if(DatosPersonales.NombreInvalido(cadena) == true)
        {

            Aviso.setText("Nombre Inv" +(char)225 +"lido");
            EntradaDireccion.setDisable(true);
            EntradaTelefono.setDisable(true);
            BotonAceptar.setDisable(true);

        }
        else
        {

            DatosPersonales.nombre = cadena;
            EntradaDireccion.setDisable(false);

        }

    }

    public void EntradaIdentidadOnAction()
    {

        String cadena = EntradaIdentidad.getText();
        if(DatosPersonales.IdentidadInvalida(cadena) == true)
        {

            Aviso.setText("N" +(char)250 +"mero de Identidad Inv" +(char)225 +"lida");
            EntradaNombre.setDisable(true);
            EntradaDireccion.setDisable(true);
            EntradaTelefono.setDisable(true);
            BotonAceptar.setDisable(true);

        }
        else
        {

            DatosPersonales.cedula = cadena;
            EntradaNombre.setDisable(false);

        }

    }

    //Metodo para cerrar la ventana
    public void BotonAceptarOnAction()
    {

        DatosPersonales.DatosBool = true;

        Stage stage = (Stage) BotonAceptar.getScene().getWindow();
        stage.close();

        DatosPersonales.ImprimirDatos();

    }

    //Metodo para cerrar la ventana
    public void BotonVolverOnAction()
    {

        // Se limpian los valores de los atributos guardados del objeto
        /* Si el cliente no ha ingresado los datos de contacto, estos se
            borran una vez que pulse el boton volver
        */
        if(DatosPersonales.DatosBool == false)
        DatosPersonales.LimpiarAtributos();

        Stage stage = (Stage) BotonVolver.getScene().getWindow();
        stage.close();

    }

    public void setStage(Stage Stage) { stage = Stage; }

    public void inicializar(String text, Stage Stage, TicketFiscalController ticketFiscalController) {

    }
}
