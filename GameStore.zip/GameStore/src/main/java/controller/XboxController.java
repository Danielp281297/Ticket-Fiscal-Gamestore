package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class XboxController {
    //ArrayList<Integer> bolsaxbox = new ArrayList<>();
    Arreglos bolsa = new Arreglos();
    @FXML
    private Button btn25,btn26,btn27,btn28,btn29,btn30,btn31,btn32,btn33,btn34,btn35,btn36;
    public void agregar(ActionEvent event){
        Object object = event.getSource();
        if(btn25.equals(object)){
            bolsa.agregarbolsa(25);

        }else if(btn26.equals(object)){
            bolsa.agregarbolsa(26);

        }else if(btn27.equals(object)){
            bolsa.agregarbolsa(27);

        }else if(btn28.equals(object)){
            bolsa.agregarbolsa(28);

        }else if(btn29.equals(object)){
            bolsa.agregarbolsa(29);

        }else if(btn30.equals(object)){
            bolsa.agregarbolsa(30);

        }else if(btn31.equals(object)){
            bolsa.agregarbolsa(31);

        }else if(btn32.equals(object)){
            bolsa.agregarbolsa(32);

        }else if(btn33.equals(object)){
            bolsa.agregarbolsa(33);

        }else if(btn34.equals(object)){
            bolsa.agregarbolsa(34);

        }else if(btn35.equals(object)){
            bolsa.agregarbolsa(35);

        }else if(btn36.equals(object)){
            bolsa.agregarbolsa(36);

        }
    }


}
