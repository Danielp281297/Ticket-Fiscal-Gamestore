package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class TodoController {
    Arreglos bolsa = new Arreglos();
    @FXML
    private Button btn_22, btn_28, btn_10, btn_25, btn_2, btn_13, btn_18, btn_23, btn_7, btn_26, btn_17, btn_8;
    public void agregar(ActionEvent event){
        Object object = event.getSource();
        if(btn_22.equals(object)){
            bolsa.agregarbolsa(22);

        }else if(btn_28.equals(object)){
            bolsa.agregarbolsa(28);


        }else if(btn_10.equals(object)){
            bolsa.agregarbolsa(10);


        }else if(btn_25.equals(object)){
            bolsa.agregarbolsa(25);

        }else if(btn_2.equals(object)){
            bolsa.agregarbolsa(2);

        }else if(btn_13.equals(object)){
            bolsa.agregarbolsa(13);

        }else if(btn_18.equals(object)){
            bolsa.agregarbolsa(18);

        }else if(btn_23.equals(object)){
            bolsa.agregarbolsa(23);

        }else if(btn_7.equals(object)){
            bolsa.agregarbolsa(7);

        }else if(btn_26.equals(object)){
            bolsa.agregarbolsa(26);

        }else if(btn_17.equals(object)){
            bolsa.agregarbolsa(17);

        }else if(btn_8.equals(object)){
            bolsa.agregarbolsa(8);

        }
    }
}
