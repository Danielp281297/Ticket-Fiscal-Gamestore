package controller;

import java.util.ArrayList;

public class VariablesDeUsoComun {

    public static ArrayList<Producto> productos = new ArrayList<>();

}


