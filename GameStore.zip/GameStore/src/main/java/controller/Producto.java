package controller;

import javafx.beans.property.*;

public class Producto {
//Declaracion de las variables a utilizar en el metodo
private  IntegerProperty id ;
    private StringProperty nombre = null;
    private StringProperty  plataforma = null;
    private IntegerProperty cantidad ;
    private DoubleProperty precio ;

//Creacion del metodo constructor

    public Producto(int id, String nombre, String plataforma, int cantidad, double precio ){
        this.id = new SimpleIntegerProperty(id);
        this.nombre= new SimpleStringProperty(nombre);
        this.plataforma=new SimpleStringProperty(plataforma);
        this.cantidad= new SimpleIntegerProperty(cantidad);
        this.precio= new SimpleDoubleProperty(precio);
    }

    public IntegerProperty getId() {
        return id;
    }

    public void setId(IntegerProperty id) {
        this.id = id;
    }

    public StringProperty getNombre() {
        return nombre;
    }

    public void setNombre(StringProperty nombre) {
        this.nombre = nombre;
    }

    public StringProperty getPlataforma() {
        return plataforma;
    }

    public void setPlataforma(StringProperty plataforma) {
        this.plataforma = plataforma;
    }

    public IntegerProperty getCantidad() {
        return cantidad;
    }

    public void setCantidad(IntegerProperty cantidad) {
        this.cantidad = cantidad;
    }

    public DoubleProperty getPrecio() {
        return precio;
    }

    public void setPrecio(DoubleProperty precio) {
        this.precio = precio;
    }
}
