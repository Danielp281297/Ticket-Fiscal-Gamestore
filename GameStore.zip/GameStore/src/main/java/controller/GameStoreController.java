package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.text.SimpleDateFormat;
import java.util.ArrayList;


import java.io.IOException;
import java.net.URL;
import java.util.Date;
import java.util.ResourceBundle;

public class GameStoreController implements Initializable {

    @FXML
    private Button btnJuegos, btnAccesorios, btnVentas, btnCarrito, btnAlmacen;

    @FXML
    private Pane ventanaCambio;
@FXML
private Label fecha, userName;


    @FXML
    private Pane accesoriosView, carritoView, facturaView, juegosView,  almacenView;


    private ArrayList<Producto> productos = VariablesDeUsoComun.productos;

    FXMLLoader loaderCar;

    @FXML
    private CarritoController carritoController;

    @FXML
    private AlmacenController almacenController;


    private boolean carritoRender;


    @FXML
    protected void exit(ActionEvent event) {

        Node node = (Node) event.getSource();

        // Obtener la ventana principal o el Stage de JavaFX
        Stage primaryStage = (Stage) node.getScene().getWindow();

        // Cerrar la ventana principal, lo que también cerrará la aplicación
        primaryStage.close();

    }


    @FXML
    public void changeView(ActionEvent event) throws IOException {
        Object object = event.getSource();
        FXMLLoader fxmlLoader = null;
       // carritoView =loadForm("/com/example/gamestore/CarritoView.fxml");

        if (btnJuegos.equals(object)) {
            juegosView.setVisible(true);
            accesoriosView.setVisible(false);
         //   carritoView.setVisible(false);
            facturaView.setVisible(false);
            almacenView.setVisible(false);

        } else if (btnAccesorios.equals(object)) {
            juegosView.setVisible(false);
            accesoriosView.setVisible(true);
           // carritoView.setVisible(false);
            facturaView.setVisible(false);
            almacenView.setVisible(false);

        } else if (btnCarrito.equals(object)) {
            juegosView.setVisible(false);
            accesoriosView.setVisible(false);

            facturaView.setVisible(false);
            almacenView.setVisible(false);
            carritoController.cargarCarro();
            carritoRender=true;
            carritoView =loadForm("/com/example/gamestore/CarritoView.fxml");
            carritoView.setVisible(true);


        } else if (btnAlmacen.equals(object)) {
           /* juegosView.setVisible(false);
            accesoriosView.setVisible(false);
           //carritoView.setVisible(false);
            facturaView.setVisible(false);
            ventasView.setVisible(false);
            almacenController.initialize();
            carritoView =loadForm("/com/example/gamestore/AlmacenView.fxml");
            almacenView.setVisible(true);
*/
            ((Node) (event.getSource())).getScene().getWindow().hide();
            Parent root = FXMLLoader.load(getClass().getResource("/com/example/gamestore/AlmacenView.fxml"));
            Scene scene = new Scene(root);
            Stage newStage = new Stage();
            newStage.setResizable(false);
            newStage.setScene(scene);
            newStage.show();


        }

    }


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        crearProducto();
        userName.setText("Usuario: "+ Arreglos.userHeader);

        try {

            accesoriosView = loadForm("/com/example/gamestore/AccesoriosView.fxml");
            CarritoController controller = new CarritoController();

            FXMLLoader loader = new FXMLLoader();
            loader.setController(controller);
            Pane pane = loader.load(getClass().getResource("/com/example/gamestore/CarritoView.fxml"));
      //    loaderCar=  (FXMLLoader) pane.getScene().getUserData();
                    //load(getClass().getResource("/com/example/gamestore/CarritoView.fxml"));

           // carritoView =pane;
                    //loadForm("/com/example/gamestore/CarritoView.fxml");
            facturaView = loadForm("/com/example/gamestore/FacturaView.fxml");
            juegosView = loadForm("/com/example/gamestore/JuegosView.fxml");
            almacenView = loadForm("/com/example/gamestore/AlmacenView.fxml");

            ventanaCambio.getChildren().addAll(accesoriosView, facturaView, juegosView, almacenView);
            //

            juegosView.setVisible(true);
            accesoriosView.setVisible(false);
         //   carritoView.setVisible(false);
            carritoRender=false;
            facturaView.setVisible(false);
            almacenView.setVisible(false);

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        fecha.setText(FechaDia());


    }


    public static String FechaDia()
    {

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String fecha = sdf.format(new Date());

        return fecha;

    }
    private Pane loadForm(String url) throws IOException {
        Pane pane = FXMLLoader.load(getClass().getResource(url));
        return pane;
    }

    public void crearProducto() {
        int idnum = 0;

        // Orden de los argumentos: String Id, String nombre, String plataforma, int cantidad, double precio
       // productos.add(new Producto(++idnum, "nombreJuego", "plataforma", 10, 10));
       // productos.add(new Producto(++idnum, "Raiman", "Xbox", 50, 5.5));
    }

    public boolean isCarritoRender() {
        return carritoRender;
    }

    public void setCarritoRender(boolean carritoRender) {
        this.carritoRender = carritoRender;
    }
}



