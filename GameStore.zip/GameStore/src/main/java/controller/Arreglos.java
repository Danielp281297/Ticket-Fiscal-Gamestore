package controller;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import modelBBDD.ConexionSqlite;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Arreglos {

    public static ArrayList<Integer> bolsa = new ArrayList<>();
    public static String bolsaString;
    public static Map<Integer, Integer> cantidadBolsa = new HashMap<>();

    public static String userHeader;

    public void agregarbolsa(int n) {
        bolsa.add(n);
        Integer contador = 0;
        Integer oldValue;
        if (cantidadBolsa.containsKey(n)) {
            contador = cantidadBolsa.get(n) + 1;
            oldValue = cantidadBolsa.get(n);
            cantidadBolsa.replace(n, oldValue, contador);
        } else {
            cantidadBolsa.put(n, 1);
        }
        for (Integer id : bolsa) {
         //   bolsaString+= id.toString()+",";
            System.out.print("|" + id + "|");
        }
        // bolsaString= bolsaString.substring(0,bolsaString.length()-1);
        System.out.println(" ");

    }

    public static String getBolsaString() {
        int i = 0;
        for (Integer id : bolsa) {
            if (i == 0) {
                bolsaString = id.toString() + ",";
            } else {
                bolsaString += id.toString() + ",";
            }
            i++;
        }
        if (bolsaString!=null && !bolsaString.isEmpty()){
            bolsaString = bolsaString.substring(0, bolsaString.length() - 1);
        }
        return bolsaString;
    }


    public static ObservableList<Producto> obtenerProductoSeleccionado() {
        ObservableList<Producto> productoList = FXCollections.observableArrayList();
        ResultSet result = null;
        Connection connection = null;

        try {
            //Obtenemos la conexion a la base de datos
            connection = ConexionSqlite.getInstance().getConnection();

            if (connection != null ) {
                //Se le indica al programa la sentencia a ejecutar

                PreparedStatement prepareStatement = connection.prepareStatement("select * from Producto where id in (" + getBolsaString() + ")");

                //Ejecutar Query es realizar la sentencia y se guarda en resul que es del tipo resulset linea 28...
                result = prepareStatement.executeQuery();

                //Creamos un ArrayList
                ;

                //Utilizamos un While para recorre la base de datos mientras hayan datos
                while (result.next()) {
                    productoList.add(new Producto(result.getInt("id"),
                            result.getString("Nombre"), result.getString("Plataforma"),
                            result.getInt("Cantidad"), result.getDouble("Precio")
                    ));
                }

                for (Producto producto : productoList) {
                    producto.setCantidad(new SimpleIntegerProperty(cantidadBolsa.get(producto.getId().intValue())));
                }

                result.close();

            } else {
                //lanzar mensaje
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {

            ConexionSqlite.getInstance().closeConnection(connection);
        }
        return productoList;
    }

    public static ObservableList<Producto> obtenerProducto() {
        ObservableList<Producto> productoList = FXCollections.observableArrayList();
        ResultSet result = null;
        Connection connection = null;


        try {
            //Obtenemos la conexion a la base de datos
            connection = ConexionSqlite.getInstance().getConnection();

            if (connection != null) {
                //Se le indica al programa la sentencia a ejecutar
                PreparedStatement prepareStatement = connection.prepareStatement("select * from Producto");

                //Ejecutar Query es realizar la sentencia y se guarda en resul que es del tipo resulset linea 28...
                result = prepareStatement.executeQuery();

                //Creamos un ArrayList
                ;

                //Utilizamos un While para recorre la base de datos mientras hayan datos
                while (result.next()) {
                    productoList.add(new Producto(result.getInt("id"),
                            result.getString("Nombre"), result.getString("Plataforma"),
                            result.getInt("Cantidad"), result.getDouble("Precio")
                    ));
                }


                result.close();
                //almacenTable.setItems(productoList);
                //state= result.next();

            } else {
                //lanzar mensaje
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {

            ConexionSqlite.getInstance().closeConnection(connection);
        }
        return productoList;
    }

    public static boolean actualizarProductosBBDD(ObservableList<Producto> productoSeleccionado) {

        ResultSet result = null;
        Connection connection = null;

        try {
            //Obtenemos la conexion a la base de datos
            connection = ConexionSqlite.getInstance().getConnection();

            if (connection != null) {
                String sql;
                //Se le indica al programa la sentencia a ejecutar
                for (Producto producto : productoSeleccionado) {

                    sql = "UPDATE Producto SET cantidad = cantidad-" + producto.getCantidad().intValue() +
                            " where ID =" + producto.getId().intValue();
                    PreparedStatement prepareStatement = connection.prepareStatement(sql);

                    //Ejecutar Query es realizar la sentencia y se guarda en resul que es del tipo resulset linea 28...
                    prepareStatement.executeUpdate();

                }

                return true;

            } else {
                //lanzar mensaje
                return false;
            }
        } catch (SQLException e) {
           // return false;
           throw new RuntimeException(e);
        } finally {

            ConexionSqlite.getInstance().closeConnection(connection);
        }

    }

}
